package in.laxbby99_.TofikPlugin;

import in.laxbby99_.TofikPlugin.events.MessageEvent;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

public class TofikPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(new MessageEvent(this), this);
        getServer().getConsoleSender().sendMessage(ChatColor.GOLD + "[TofikPlugin] This Plugin is now enabled!");
    }

    @Override
    public void onDisable() {
        getServer().getConsoleSender().sendMessage(ChatColor.GOLD + "[TofikPlugin] This Plugin is now disabled");
    }
}